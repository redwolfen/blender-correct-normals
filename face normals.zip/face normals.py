bl_info = {
    "name": "RodlumNormals",
    "author": "Rodolf Guanco Lumampao",
    "description": "Correct normals.",
    "blender": (3, 0, 0),
    "version": (1, 0, 0),
    "location": "View3D > Sidebar > Check Normals",
    "warning": "",
    "doc_url": "",
    "category": "Mesh Normals",
}


import bpy

class CheckNormalsOperator1(bpy.types.Operator):
    """Check for inverted face normals"""
    bl_idname = "object.check_normals"
    bl_label = "Check Normals1"

    def execute(self, context):
        # get the active object
        obj = context.active_object

        # switch to object mode and deselect all
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')

        # select the object
        obj.select_set(True)
        context.view_layer.objects.active = obj

        # show face normals
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='EDIT')
#        bpy.context.space_data.overlay.show_face_normals = True

        # check for inverted normals
        inverted_normals = []
        for poly in obj.data.polygons:
            if poly.normal.z < 0:
                inverted_normals.append(poly.index)

        # prompt user if there are inverted normals
        if inverted_normals:
            message = "There are inverted normals on faces: "
            for i in inverted_normals:
                message += str(i+1) + ", "
            message = message[:-2]
            self.report({'WARNING'}, message)
        else:
            self.report({'INFO'}, "All normals are facing outwards.")

        return {'FINISHED'}
    
class SetEndFrameOperator(bpy.types.Operator):
    """Set the timeline end frame to the value entered by the user"""
    bl_idname = "screen.set_end_frame"
    bl_label = "Set End Frame"
    bl_options = {'REGISTER', 'UNDO'}

    frame_end: bpy.props.IntProperty(
        name="End Frame",
        default=250,
        min=1,
        max=1000
    )

    def execute(self, context):
        bpy.context.scene.frame_end = self.frame_end
        bpy.context.scene.render.fps = 24  # set the frame rate
        return {'FINISHED'}

class CreateTurntableOperator(bpy.types.Operator):
    """Create a turntable animation for the selected object"""
    bl_idname = "object.create_turntable"
    bl_label = "Create Turntable"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Get the active object
        obj = bpy.context.active_object     
        # Check if an empty for the turntable already exists
        empty_name = obj.name + "_turntable_empty"
        if empty_name in bpy.data.objects:
            empty = bpy.data.objects[empty_name]
        else:
            # Create a new empty
            empty = bpy.data.objects.new(empty_name, None)
            bpy.context.scene.collection.objects.link(empty)

        # Parent the object to the empty
        obj.parent = empty
        bpy.context.view_layer.objects.active = obj

        # Set the rotation mode to Euler
        empty.rotation_mode = 'XYZ'

        # Add rotation keyframes for every frame
        end_frames = context.scene.turntable_end_frames
        for i in range(end_frames):
            bpy.context.scene.frame_set(i)
            empty.rotation_euler.z = 2 * 3.14159 * i / end_frames
            empty.keyframe_insert(data_path="rotation_euler", index=-1, frame=i, options={'INSERTKEY_VISUAL'})

        # Clean up the animation data
        bpy.ops.screen.animation_cancel(restore_frame=False)
        bpy.ops.action.clean()

        # Deselect everything
        bpy.ops.object.select_all(action='DESELECT')

        # Select only the original object
        obj.select_set(True)

        # Set the view to show the selected object
        bpy.ops.view3d.camera_to_view_selected()

        # Set the end frames as the default and reset to frame 1
        bpy.context.scene.render.fps = 24  # set the frame rate
        bpy.context.scene.frame_end = end_frames

        return {'FINISHED'}

class CheckNormalsPanel1(bpy.types.Panel):
    """Creates a Panel in the 3D Viewport"""
    bl_label = "Normals"
    bl_idname = "OBJECT_PT_check_normals_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Correct Normals'

    def draw(self, context):
        layout = self.layout
        
        # Add button to execute check normals operator
        layout.operator("object.check_normals", text="Correct Normals")

        # Add button to toggle face orientation
        layout.prop(context.space_data.overlay, "show_face_normals", text="Face Normal Lines")
        # Add button to toggle face orientation
        box = layout.box()
        box.prop(context.space_data.overlay, "show_face_orientation", text="Show Face normals")
        box.prop(context.space_data.overlay, "show_stats", text="Show Statistics")
        row = layout.row()
        row.prop(context.scene, "turntable_end_frames", text="End Frames")
        row.operator("screen.set_end_frame", text="Set End Frame").frame_end = context.scene.turntable_end_frames
        # column layout
        col = layout.column(align=True)
        col.scale_y = 1.5
        col.operator("object.create_turntable", text="Create Turntable")
        col.operator("view3d.camera_to_view", text="Camera to View")

def register():
    bpy.utils.register_class(CheckNormalsOperator1)
    bpy.utils.register_class(CheckNormalsPanel1)
    bpy.utils.register_class(SetEndFrameOperator)
    bpy.utils.register_class(CreateTurntableOperator)
    bpy.types.Scene.turntable_end_frames = bpy.props.IntProperty(
        name="End Frames",
        default=250,
        min=1,
        max=1000
    )


def unregister():
    bpy.utils.unregister_class(CheckNormalsOperator1)
    bpy.utils.unregister_class(CheckNormalsPanel1)
    bpy.utils.unregister_class(SetEndFrameOperator)
    bpy.utils.unregister_class(CreateTurntableOperator)
    del bpy.types.Scene.turntable_end_frames

    
if __name__ == "__main__":
    register()
